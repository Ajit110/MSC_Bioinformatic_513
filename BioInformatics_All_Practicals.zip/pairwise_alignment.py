se1=input("Enter the First sequence::")
se2=input("Enter the Second sequence::")
seq1=list(se1)
seq2=list(se2)
score=[]

def pairwise_alignment(a,b):
    gap(a,b)
    print(a)
    print(b)
    value=0
    length=len(a)
    for i in range(0,length):
        if(a[i]==b[i]):
            score.append('1')
            valuye=value+1
        else:
             score.append('0')
    print(score)
    print(value)

def gap(a,b):
    if(len(a)==len(b)):
        print()
    else:
        k=int(input("Enter the position to insert::"))
        if(len(a)<len(b)):
            a.insert(k,'-')
        else:
            b.insert(k,'-')
    return(a,b)

pairwise_alignment(seq1,seq2)

            
              
            
